require 'httparty'
require 'json'
require 'colorize'
require 'artii'
require 'faker'
require 'securerandom'
require 'date'
require 'concurrent'

def load_config
  begin
    File.open('configuration.json', 'r') { |file| JSON.parse(file.read) }
  rescue
    puts "Error: configuration.json not found!".red.bold
    { 'referral_code' => '4OHDRQ', 'batch_size' => 300, 'use_batch' => true }
  end
end

def load_proxies
  begin
    File.readlines('proxy.txt').map(&:strip).reject(&:empty?)
  rescue
    puts "Error: proxy.txt not found!".red.bold
    []
  end
end

def generate_random_gmail
  "#{Faker::Name.first_name.downcase}.#{Faker::Name.last_name.downcase}#{rand(1000..9999)}@gmail.com"
end

def generate_random_x_username
  "#{('a'..'z').to_a.sample(5).join}_x#{rand(100..999)}"
end

def generate_evm_address
  "0x#{SecureRandom.hex(20)}"
end

def send_request(url, headers, proxies, config)
  email = generate_random_gmail
  wallet_address = generate_evm_address
  x_username = generate_random_x_username
  referral_code = config['referral_code']
  payload = {
    email: email,
    walletAddress: wallet_address,
    twitterUsername: x_username,
    referralCode: referral_code
  }
  puts "Email: #{email}".yellow.bold
  puts "Wallet Address: #{wallet_address}".yellow.bold
  puts "X Username: #{x_username}".yellow.bold
  puts "Referral Code: #{referral_code}".yellow.bold
  proxy = proxies.empty? ? nil : proxies.sample
  options = {
    headers: headers,
    body: payload.to_json,
    timeout: 10
  }
  options[:http_proxyaddr], options[:http_proxyport] = proxy.split(':') if proxy
  begin
    response = HTTParty.post(url, options)
    if response.code == 200
      puts "Success: Data sent successfully!".green.bold
    else
      puts "Failed: Status code #{response.code}".red.bold
    end
  rescue => e
    puts "Error: #{e.message}".red.bold
  end
end

def send_batch_requests(url, headers, proxies, config)
  loop do
    puts "Sending batch of #{config['batch_size']} requests...".green.bold
    pool = Concurrent::FixedThreadPool.new(config['batch_size'])
    config['batch_size'].times do
      pool.post do
        send_request(url, headers, proxies, config)
      end
    end
    pool.shutdown
    pool.wait_for_termination
    puts "Batch completed, starting next batch...".green.bold
  end
end

def send_single_requests(url, headers, proxies, config)
  loop { send_request(url, headers, proxies, config) }
end

def main
  print "\033]2;Mintro Auto Reff by: 佐賀県産 (YUURI)\007"
  puts Artii::Base.new.asciify('Yuurisandesu').cyan.bold
  puts 'Welcome to Yuuri Mintro Auto Reff'.magenta.bold
  puts 'Ready to hack the world?'.green.bold
  puts "Current time: #{Time.now.strftime('%d-%m-%Y %H:%M:%S')}".yellow.bold
  puts
  url = 'https://mintro.ai/api/waitlist'
  headers = {
    'accept' => '*/*',
    'content-type' => 'application/json',
    'origin' => 'https://mintro.ai',
    'referer' => 'https://mintro.ai/waitlist',
    'user-agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36'
  }
  config = load_config
  proxies = load_proxies
  if proxies.empty?
    puts 'No valid proxies found, continuing without proxies...'.yellow.bold
  end
  if config['use_batch']
    send_batch_requests(url, headers, proxies, config)
  else
    send_single_requests(url, headers, proxies, config)
  end
end

main if __FILE__ == $PROGRAM_NAME
